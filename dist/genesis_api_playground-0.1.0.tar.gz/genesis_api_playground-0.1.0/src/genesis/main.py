import requests
import configparser

# Read the configuration file
config = configparser.ConfigParser()
config.read('config.ini')

# Retrieve the API settings
endpoint = config.get('api', 'endpoint')
api_key = config.get('api', 'api_key')

# Define the headers
headers = {
    "X-API-KEY": api_key,
    "Content-Type": "application/json"
}

# Define a sample GraphQL query
query = """
{
  exampleField {
    id
    name
  }
}
"""

def run_query(query):
    """Run a GraphQL query against the Genesis API."""
    response = requests.post(endpoint, json={'query': query}, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Request failed with status code {response.status_code}")
        print(response.text)
        return None

# Example usage
if __name__ == "__main__":
    result = run_query(query)
    if result:
        print(result)
